import { app } from "./router";
export default app;
